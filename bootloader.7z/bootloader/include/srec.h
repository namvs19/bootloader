#ifndef __SREC_H__
#define __SREC_H__

/*******************************************************************************
 * Includes
 ******************************************************************************/
#include "std_type.h"
/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define SREC_RECORD_LENGTH 80u

typedef struct
{
    uint8_t record[SREC_RECORD_LENGTH];
} SREC_Record_Type;

typedef struct
{
    uint32_t u32Address;
    uint8_t *data;
    uint8_t u8DataSize;
    uint8_t u8RecordType;
} SREC_Infomation_Type;

/*******************************************************************************
 * API
 ******************************************************************************/

uint8_t SREC_GetSrecInfo(const uint8_t *record, SREC_Infomation_Type *info);

#endif /* __SREC_H__ */