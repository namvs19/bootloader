#ifndef _STD_BOOL
#define _STD_BOOL

#ifndef _SYSTEM_BUILD
#pragma system_include
#endif

#include "std_type.h"

typedef uint8_t bool_t;
#define true (1u)
#define false (0)

#endif _STD_BOOL